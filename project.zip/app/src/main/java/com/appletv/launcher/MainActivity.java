package com.appletv.launcher;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;

public class MainActivity extends Activity {

    // Layout in a 1920-wide design space; everything is scaled by s.
    static final int TW = 380, TH = 214, PX = 430, X0 = 125;
    static final int DOCK_Y = 60, GRID_Y = 360, ROW = 300, HL = 8;
    // Dock apps, in order. Matched against app names on the TV.
    static final String[] DOCK_KEYS = {"youtube", "google", "opera", "chrome"};

    static class App {
        String label, pkg;
        ComponentName cn;
        Drawable icon;
        int color;
        FrameLayout card;
        TextView name;
        int x, y;
    }

    float s;
    int W, H;
    FrameLayout root, content;
    ScrollView scroll;
    View highlight, glow;
    TextView dockName, greeting;
    TextView[] pills = new TextView[3];
    ArrayList<App> all = new ArrayList<App>();
    ArrayList<App> dock = new ArrayList<App>();
    ArrayList<App> grid = new ArrayList<App>();
    int zone = 1, topIdx = 0, dockIdx = 0, gridIdx = 0;
    App prev;
    boolean placed, dirty, resumed;

    BroadcastReceiver rx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            dirty = true;
            if (resumed) refreshApps();
        }
    };

    int p(float v) { return Math.round(v * s); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));
        DisplayMetrics dm = getResources().getDisplayMetrics();
        W = Math.max(dm.widthPixels, dm.heightPixels);
        H = Math.min(dm.widthPixels, dm.heightPixels);
        s = W / 1920f;
        buildStatic();
        loadApps();
        buildContent();
        clamp();
        applyFocus();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addDataScheme("package");
        registerReceiver(rx, f);
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(rx); } catch (Exception e) { }
        super.onDestroy();
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        refreshTexts();
        if (dirty) refreshApps();
    }

    @Override protected void onPause() {
        resumed = false;
        super.onPause();
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        dockIdx = 0;
        zone = dock.isEmpty() ? (grid.isEmpty() ? 0 : 2) : 1;
        applyFocus();
    }

    // ---------- UI building ----------

    GradientDrawable rr(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(p(radius));
        return g;
    }

    TextView tv(float px, int color, String family) {
        TextView t = new TextView(this);
        style(t, px, color, family);
        return t;
    }

    void style(TextView t, float px, int color, String family) {
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, p(px));
        t.setTextColor(color);
        t.setTypeface(Typeface.create(family, Typeface.NORMAL));
        t.setIncludeFontPadding(false);
    }

    void put(ViewGroup g, View v, int x, int y, int w, int h) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                w > 0 ? p(w) : ViewGroup.LayoutParams.WRAP_CONTENT,
                h > 0 ? p(h) : ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = p(x);
        lp.topMargin = p(y);
        g.addView(v, lp);
    }

    void buildStatic() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        glow = new View(this);
        FrameLayout.LayoutParams gl = new FrameLayout.LayoutParams(p(600), p(600));
        gl.leftMargin = (W - p(600)) / 2;
        gl.topMargin = p(225) - p(300);
        glow.setScaleX(2.2f);
        glow.setAlpha(0f);
        root.addView(glow, gl);

        greeting = tv(34, 0xFF9E9EA3, "sans-serif-light");
        put(root, greeting, 104, 30, 0, 0);

        TextClock clock = new TextClock(this);
        style(clock, 104, Color.WHITE, "sans-serif-thin");
        clock.setFormat12Hour("h:mm");
        clock.setFormat24Hour("H:mm");
        put(root, clock, 100, 66, 0, 0);

        TextClock date = new TextClock(this);
        style(date, 30, 0xFFB0B0B5, "sans-serif-light");
        date.setFormat12Hour("EEEE, d MMMM");
        date.setFormat24Hour("EEEE, d MMMM");
        put(root, date, 104, 196, 0, 0);

        dockName = tv(46, Color.WHITE, "sans-serif-light");
        dockName.setGravity(Gravity.CENTER);
        dockName.setSingleLine(true);
        dockName.setAlpha(0f);
        put(root, dockName, 0, 190, 1920, 70);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Inputs", "Wi-Fi", "Settings"};
        for (int i = 0; i < 3; i++) {
            TextView t = tv(28, Color.WHITE, "sans-serif");
            t.setText(names[i]);
            t.setGravity(Gravity.CENTER);
            t.setPadding(p(40), p(18), p(40), p(18));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = p(20);
            row.addView(t, lp);
            pills[i] = t;
            stylePill(i, false);
        }
        FrameLayout.LayoutParams rl = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.RIGHT);
        rl.topMargin = p(40);
        rl.rightMargin = p(100);
        root.addView(row, rl);

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setFocusable(false);
        FrameLayout.LayoutParams sl = new FrameLayout.LayoutParams(W, H - p(300));
        sl.topMargin = p(300);
        root.addView(scroll, sl);

        content = new FrameLayout(this);
        scroll.addView(content, new FrameLayout.LayoutParams(W, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    void stylePill(int i, boolean f) {
        TextView t = pills[i];
        t.setBackground(rr(f ? 0xEEFFFFFF : 0x40FFFFFF, 40));
        t.setTextColor(f ? 0xFF111111 : Color.WHITE);
        t.animate().scaleX(f ? 1.08f : 1f).scaleY(f ? 1.08f : 1f).setDuration(150);
    }

    void buildContent() {
        content.removeAllViews();
        prev = null;
        placed = false;
        int rows = (grid.size() + 3) / 4;
        content.setMinimumHeight(p(GRID_Y + rows * ROW + 140));

        if (!dock.isEmpty()) {
            View band = new View(this);
            band.setBackground(rr(0xFF161618, 48));
            put(content, band, 100, 20, 1720, 294);
        }
        for (int i = 0; i < dock.size(); i++) card(dock.get(i), X0 + i * PX, DOCK_Y, false);
        for (int i = 0; i < grid.size(); i++)
            card(grid.get(i), X0 + (i % 4) * PX, GRID_Y + (i / 4) * ROW, true);

        highlight = new View(this);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x38FFFFFF);
        g.setStroke(p(3), 0x99FFFFFF);
        g.setCornerRadius(p(34));
        highlight.setBackground(g);
        put(content, highlight, 0, 0, TW + 2 * HL, TH + 2 * HL);
        highlight.setScaleX(1.08f);
        highlight.setScaleY(1.08f);
        highlight.setAlpha(0f);
    }

    void card(App a, int x, int y, boolean showName) {
        a.x = x;
        a.y = y;
        FrameLayout c = new FrameLayout(this);
        c.setBackground(rr(0xFF2C2C2F, 28));
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(a.icon);
        c.addView(iv, new FrameLayout.LayoutParams(p(140), p(140), Gravity.CENTER));
        put(content, c, x, y, TW, TH);
        a.card = c;
        a.name = null;
        if (showName) {
            TextView n = tv(28, Color.WHITE, "sans-serif");
            n.setText(a.label);
            n.setGravity(Gravity.CENTER);
            n.setSingleLine(true);
            n.setEllipsize(android.text.TextUtils.TruncateAt.END);
            n.setAlpha(0f);
            put(content, n, x, y + TH + 20, TW, 44);
            a.name = n;
        }
    }

    // ---------- Apps ----------

    void loadApps() {
        PackageManager pm = getPackageManager();
        LinkedHashMap<String, App> map = new LinkedHashMap<String, App>();
        String[] cats = {"android.intent.category.LEANBACK_LAUNCHER", Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || map.containsKey(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.label = String.valueOf(ri.loadLabel(pm));
                a.cn = new ComponentName(pkg, ri.activityInfo.name);
                a.icon = ri.loadIcon(pm);
                map.put(pkg, a);
            }
        }
        all = new ArrayList<App>(map.values());
        Collections.sort(all, new Comparator<App>() {
            @Override public int compare(App x, App y) {
                return x.label.compareToIgnoreCase(y.label);
            }
        });

        dock = new ArrayList<App>();
        for (String key : DOCK_KEYS) {
            App best = null;
            int bs = 99;
            for (App a : all) {
                if (dock.contains(a)) continue;
                String l = a.label.toLowerCase();
                int sc = 99;
                if (l.equals(key)) sc = 0;
                else if (l.startsWith(key)) sc = 1;
                else if (l.contains(key)) sc = 2;
                else if (key.equals("chrome") && l.equals("browser")) sc = 3;
                if (key.equals("google") && l.contains("play")) sc = 99;
                if (sc < bs) { bs = sc; best = a; }
            }
            if (best != null) { best.color = sample(best.icon); dock.add(best); }
        }
        grid = new ArrayList<App>();
        for (App a : all) if (!dock.contains(a)) grid.add(a);
    }

    int sample(Drawable d) {
        try {
            Bitmap bm = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bm);
            d.setBounds(0, 0, 24, 24);
            d.draw(c);
            long r = 0, g = 0, b = 0, w = 0;
            for (int x = 0; x < 24; x++) {
                for (int y = 0; y < 24; y++) {
                    int px = bm.getPixel(x, y);
                    if (Color.alpha(px) < 128) continue;
                    int rr = Color.red(px), gg = Color.green(px), bb = Color.blue(px);
                    int wt = Math.max(rr, Math.max(gg, bb)) - Math.min(rr, Math.min(gg, bb)) + 10;
                    r += rr * wt; g += gg * wt; b += bb * wt; w += wt;
                }
            }
            bm.recycle();
            if (w == 0) return 0xFF5E5CE6;
            int R = (int) (r / w), G = (int) (g / w), B = (int) (b / w);
            int m = Math.max(R, Math.max(G, B));
            if (m > 0 && m < 150) {
                float f = 150f / m;
                R = Math.min(255, (int) (R * f));
                G = Math.min(255, (int) (G * f));
                B = Math.min(255, (int) (B * f));
            }
            return Color.rgb(R, G, B);
        } catch (Exception e) {
            return 0xFF5E5CE6;
        }
    }

    void refreshApps() {
        dirty = false;
        loadApps();
        buildContent();
        clamp();
        applyFocus();
    }

    void clamp() {
        dockIdx = Math.max(0, Math.min(dockIdx, dock.size() - 1));
        gridIdx = Math.max(0, Math.min(gridIdx, grid.size() - 1));
        if (zone == 1 && dock.isEmpty()) zone = grid.isEmpty() ? 0 : 2;
        if (zone == 2 && grid.isEmpty()) zone = dock.isEmpty() ? 0 : 1;
    }

    // ---------- Focus & navigation ----------

    void applyFocus() {
        if (prev != null) {
            prev.card.animate().scaleX(1f).scaleY(1f).setDuration(200);
            if (prev.name != null) prev.name.animate().alpha(0f).setDuration(150);
            prev = null;
        }
        for (int i = 0; i < 3; i++) stylePill(i, zone == 0 && i == topIdx);

        App a = null;
        if (zone == 1 && !dock.isEmpty()) a = dock.get(dockIdx);
        else if (zone == 2 && !grid.isEmpty()) a = grid.get(gridIdx);

        if (a != null) {
            float tx = p(a.x - HL), ty = p(a.y - HL);
            if (!placed) {
                highlight.setTranslationX(tx);
                highlight.setTranslationY(ty);
                highlight.setAlpha(1f);
                placed = true;
            } else {
                highlight.animate().translationX(tx).translationY(ty).alpha(1f)
                        .setDuration(320).setInterpolator(new OvershootInterpolator(1.15f));
            }
            a.card.animate().scaleX(1.08f).scaleY(1.08f).setDuration(220);
            if (a.name != null) a.name.animate().alpha(1f).setDuration(200);
            prev = a;
        } else {
            highlight.animate().alpha(0f).setDuration(150).setInterpolator(new DecelerateInterpolator());
        }

        if (zone == 1 && a != null) {
            dockName.setText(a.label);
            dockName.animate().alpha(1f).setDuration(200);
            GradientDrawable g = new GradientDrawable();
            g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
            g.setGradientRadius(p(300));
            int rgb = a.color & 0xFFFFFF;
            g.setColors(new int[]{(0x80 << 24) | rgb, rgb});
            glow.setBackground(g);
            glow.animate().alpha(1f).setDuration(300);
        } else {
            dockName.animate().alpha(0f).setDuration(150);
            glow.animate().alpha(0f).setDuration(200);
        }

        int target = (zone == 2 && a != null) ? Math.max(0, p(a.y - 200)) : 0;
        scroll.smoothScrollTo(0, target);
    }

    void move(int k) {
        switch (zone) {
            case 0:
                if (k == KeyEvent.KEYCODE_DPAD_LEFT) topIdx = Math.max(0, topIdx - 1);
                else if (k == KeyEvent.KEYCODE_DPAD_RIGHT) topIdx = Math.min(2, topIdx + 1);
                else if (k == KeyEvent.KEYCODE_DPAD_DOWN) {
                    if (!dock.isEmpty()) zone = 1;
                    else if (!grid.isEmpty()) zone = 2;
                }
                break;
            case 1:
                if (k == KeyEvent.KEYCODE_DPAD_LEFT) dockIdx = Math.max(0, dockIdx - 1);
                else if (k == KeyEvent.KEYCODE_DPAD_RIGHT) dockIdx = Math.min(dock.size() - 1, dockIdx + 1);
                else if (k == KeyEvent.KEYCODE_DPAD_UP) zone = 0;
                else if (k == KeyEvent.KEYCODE_DPAD_DOWN && !grid.isEmpty()) {
                    zone = 2;
                    gridIdx = Math.min(dockIdx, grid.size() - 1);
                }
                break;
            case 2:
                if (k == KeyEvent.KEYCODE_DPAD_LEFT) {
                    if (gridIdx % 4 > 0) gridIdx--;
                } else if (k == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    if (gridIdx % 4 < 3 && gridIdx + 1 < grid.size()) gridIdx++;
                } else if (k == KeyEvent.KEYCODE_DPAD_UP) {
                    if (gridIdx >= 4) gridIdx -= 4;
                    else if (!dock.isEmpty()) {
                        zone = 1;
                        dockIdx = Math.min(gridIdx % 4, dock.size() - 1);
                    } else zone = 0;
                } else if (k == KeyEvent.KEYCODE_DPAD_DOWN) {
                    if (gridIdx + 4 < grid.size()) gridIdx += 4;
                    else if (gridIdx / 4 < (grid.size() - 1) / 4) gridIdx = grid.size() - 1;
                }
                break;
        }
        applyFocus();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        boolean nav = k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT
                || k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN;
        boolean ok = k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER
                || k == KeyEvent.KEYCODE_NUMPAD_ENTER;
        if (nav || ok || k == KeyEvent.KEYCODE_BACK) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) {
                if (nav) move(k);
                else if (ok && e.getRepeatCount() == 0) activate();
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    // ---------- Actions ----------

    void activate() {
        if (zone == 0) {
            if (topIdx == 0) openInputs();
            else if (topIdx == 1) open(new Intent(Settings.ACTION_WIFI_SETTINGS));
            else open(new Intent(Settings.ACTION_SETTINGS));
        } else if (zone == 1 && !dock.isEmpty()) launch(dock.get(dockIdx));
        else if (zone == 2 && !grid.isEmpty()) launch(grid.get(gridIdx));
    }

    void open(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Cannot open", Toast.LENGTH_SHORT).show();
        }
    }

    void launch(App a) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setComponent(a.cn);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Cannot open " + a.label, Toast.LENGTH_SHORT).show();
        }
    }

    void openInputs() {
        String[] hints = {"source", "input", "hdmi"};
        for (String h : hints) {
            for (App a : all) {
                if (a.label.toLowerCase().contains(h)) { launch(a); return; }
            }
        }
        Toast.makeText(this, "Input/Source app not found on this TV", Toast.LENGTH_LONG).show();
    }

    String wifiName() {
        try {
            WifiManager w = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo i = w.getConnectionInfo();
            if (i != null && i.getNetworkId() != -1) {
                String ss = i.getSSID();
                if (ss != null) {
                    ss = ss.replace("\"", "");
                    if (ss.length() > 0 && !ss.equals("<unknown ssid>")) return ss;
                }
                return "Connected";
            }
        } catch (Exception e) { }
        return "Not connected";
    }

    void refreshTexts() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        greeting.setText(h < 5 ? "Good night" : h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening");
        pills[1].setText("Wi-Fi \u00B7 " + wifiName());
    }
}
